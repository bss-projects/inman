EJDB .Net Binding moved into: https://github.com/Softmotions/ejdb-csharp



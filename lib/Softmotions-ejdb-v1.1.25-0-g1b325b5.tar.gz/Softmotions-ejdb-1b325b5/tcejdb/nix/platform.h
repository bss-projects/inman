/*
 * File:   platform.h
 * Author: adam
 *
 * Created on April 21, 2013, 10:27 PM
 */

#ifndef PLATFORM_H
#define	PLATFORM_H

#include "../basedefs.h"
#include <stdbool.h>

EJDB_EXTERN_C_START

bool closefd(int fd);

EJDB_EXTERN_C_END

#endif	/* PLATFORM_H */

